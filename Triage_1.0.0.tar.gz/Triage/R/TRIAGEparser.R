#' @title TRIAGEparser
#' 
#' @description TRIAGEparser is a machine learning-based method that evaluates gene expression rank lists to identify gene groups governing cell identity 
#' and function. It performs principal component analysis to extract orthogonal patterns of H3K27me3 depositions from consortium-level epigenomic data and 
#' uses Bayesian information criterion to optimally determine gene clusters. TRIAGEparser then assesses each gene cluster by searching the protein-protein 
#' interaction (PPI) networks from the STRING database and conducts Gene Ontology enrichment analysis for genes with direct PPI interactions. 
#' For more in-depth details, refer to: Sun et al., Nucleic Acid Research 2023, "Inferring cell diversity in single cell data using consortium-scale 
#' epigenetic data as a biological anchor for cell identity".
#' 
#' Run TRIAGEparser using specified parameters
#'
#' @param input The input file path in CSV format or a tab/space-delimited text file.
#' @param input_type The input type, either 'table' or 'list'. Default is 'list'.
#' @param outdir The output directory path.
#' @param H3K27me3_pc The path to pre-calculated H3K27me3 principal components. Default is pca_roadmap.
#' @param number_of_pca The number of principal components to use. Default is 10.
#' @param number_of_gene The number of top genes to use. Default is 100.
#' @param no_iter Number of iterations for determining the best number of clusters using the Bayesian Information Criterion (BIC). Default is 100.
#' @param EM_tol The convergence threshold for the GaussianMixture function. Expectation–maximization (EM) iterations will stop when the lower bound average gain is below this threshold. Default is 1e-3.
#' @param EM_max_iter The number of EM iterations to perform for the GaussianMixture function. Default is 100.
#' @param go_analysis Whether to perform GO enrichment analysis. (1: Yes, 0: No). Default is 1.
#' @param verbose The level of verbosity (option: 1 or 0). Default is 1.
#' @param max_cluster The maximum number of clusters. Default is 10.
#' @param gene_order Specifies the direction to sort genes (option: ascending or descending). Default is descending.
#' @param go_threshold The GO term enrichment threshold (FDR). Default is 0.01.
#' @return The function runs the TRIAGEparser analysis and generates output in the specified directory.
#' @export
#' @examples
#'\dontrun{
#' # Apply TRIAGEparser using a tab-delimited table file "input.txt" and 
#' # specify the output directory as "path/to/results".
#' TRIAGEparser("input.txt", input_type = "table", outdir = "path/to/results")
#'
#' # Apply TRIAGEparser using "input.txt" as a gene list and 
#' # specify the output directory as "path/to/results".
#' TRIAGEparser("input.txt", outdir = "path/to/results")
#'
#' # Apply TRIAGEparser using a CSV file "input.csv" and 
#' # specify the output directory as "path/to/results".
#' TRIAGEparser("input.csv", input_type = "table", outdir = "path/to/results")
#' }


TRIAGEparser <- function(input, 
                         input_type = "list", 
                         outdir = "TRIAGEparser_output",
                         H3K27me3_pc = "pca_roadmap",
                         number_of_pca = 10, 
                         number_of_gene = 100, 
                         no_iter = 100,
                         EM_tol = 1e-3, 
                         EM_max_iter = 100, 
                         go_analysis = 1, 
                         verbose = 1, 
                         max_cluster = 10,
                         gene_order = "descending",
                         go_threshold = 0.01) {
  H3K27me3_pc_path <- system.file("extdata", paste0(H3K27me3_pc, ".csv"), package = "Triage")
  #print(paste("H3K27me3_pc_path:", H3K27me3_pc_path))
  H3K27me3_pc_path2 <- gsub("\\.csv$", "", H3K27me3_pc_path)
  #print(paste("H3K27me3_pc_path2:", H3K27me3_pc_path2))
  outdir <- normalizePath(outdir, mustWork = FALSE)
  
  path <- system.file("python", "TRIAGEparser.py", package = "Triage")

  script_command <- sprintf(
    "sys.argv = ['%s', '--input', '%s', '--input_type', '%s', '--outdir', '%s', '--H3K27me3_pc', '%s', '--number_of_pca', '%s', '--number_of_gene', '%s', '--no_iter', '%s', '--EM_tol', '%s', '--EM_max_iter', '%s', '--go_analysis', '%s', '--verbose', '%s', '--max_cluster', '%s', '--gene_order', '%s', '--go_threshold', '%s']",
    gsub("\\\\", "/", normalizePath(path, winslash="/", mustWork=FALSE)),
    input,
    input_type,
    gsub("\\\\", "/", normalizePath(outdir, winslash="/", mustWork=FALSE)),
    gsub("\\\\", "/", normalizePath(H3K27me3_pc_path2, winslash="/", mustWork=FALSE)),
    number_of_pca,
    number_of_gene,
    no_iter,
    EM_tol,
    EM_max_iter,
    go_analysis,
    verbose,
    max_cluster,
    gene_order,
    go_threshold)
  
  # tryCatch for error handling
  tryCatch({
    reticulate::py_run_string("import sys")
    reticulate::py_run_string(script_command)
    reticulate::py_run_file(path)
  }, error = function(e) {
    stop("Error occurred while executing the Python script: ", e$message)
  })
  
  # print messages
  #message("Python script path: ", path)
  #message("TRIAGEparser completed!")
}


