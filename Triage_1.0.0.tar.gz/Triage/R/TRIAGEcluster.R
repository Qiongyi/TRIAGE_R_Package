#' @title TRIAGEcluster
#'
#' @description 
#' TRIAGEcluster represents a significant advancement in single-cell RNA sequencing (scRNA-seq) analysis, with a transformative impact on its ability to discern and characterize unique cell types within complex biological samples. 
#' It integrates gene-level information inferred from H3K27me3 signatures, a key component of the RTS metric from TRIAGEgene, targeting the discovery and visualization of cell clusters in scRNA-seq data. 
#' Focusing on cells expressing high RTS genes and the corresponding peaks (i.e. cell clusters), where these high RTS genes act as anchor genes, TRIAGEcluster is able to pinpointing biologically distinct cell populations. 
#' For more in-depth details, refer to: Sun et al., Nucleic Acid Research 2023, "Inferring cell diversity in single cell data using consortium-scale epigenetic data as a biological anchor for cell identity".
#' 
#' Run TRIAGEcluster using specified parameters.
#'
#' @param expr The discordance score matrix file or gene expression matrix file (.csv or tab delimited .txt file).
#' @param metadata The metadata file (.csv or tab delimited .txt file).
#' @param outdir The output directory (optional, default: "TRIAGEcluster_results").
#' @param output_prefix The output file prefix (optional, default: "TRIAGEcluster").
#' @param cell_column Column name for cells (optional, default: "Barcode").
#' @param umap_column Prefix for UMAP coordinate columns (optional, default: "UMAP_").
#' @param priority_rts Path to the priority RTS gene list file (optional, default: "Priority_epimap_rts.csv").
#' @param min_cells_per_peak Minimum number of cells per peak (optional, default: 5).
#' @return The function runs the TRIAGEcluster analysis and generates output in the specified directory.
#' @export
#' @examples
#'\dontrun{
#' # Using a .csv discordance score matrix and a tab-delimited .txt metadata file. 
#' # Output will be saved in "TRIAGEcluster_results" with the prefix "project1".
#' # The metadata file has "Barcode" for cells and "UMAP_1", "UMAP_2" for UMAP columns.
#' TRIAGEcluster("ds.csv", "metadata.txt", 
#'               outdir = "TRIAGEcluster_results", 
#'               output_prefix = "project1")

#' # Using a tab-delimited .txt discordance score matrix and a .csv metadata file. 
#' # Output will be in "TRIAGEcluster_results" with the prefix "project2".
#' # The metadata file uses "Cells" for cells and "UMAP1", "UMAP2" for UMAP columns.
#' TRIAGEcluster(expr = "ds.txt", 
#'               metadata = "metadata.csv", 
#'               output_prefix = "project2", 
#'               cell_column = "Cells",  
#'               umap_column = "UMAP")

#' # Using .csv files for both gene expression matrix and metadata. 
#' # Outputs will be in "TRIAGEcluster_results" with the prefix "project3".
#' TRIAGEcluster("Expr_matrix.csv", "metadata.csv", output_prefix = "project3")

#' # Using tab-delimited .txt files for both gene expression matrix and metadata. 
#' # Outputs will be in "results" with the prefix "project4".
#' TRIAGEcluster("Expr_matrix.txt", 
#'               "metadata.txt", 
#'               outdir = "results", 
#'               output_prefix = "project4")
#' }

TRIAGEcluster <- function(expr, metadata, outdir = "TRIAGEcluster_results", output_prefix = "TRIAGEcluster", cell_column = "Barcode", umap_column = "UMAP_", priority_rts = "Priority_epimap_rts.csv", min_cells_per_peak = 5) {
  path <- system.file("python", "TRIAGEcluster.py", package = "Triage")
  
  if (!file.exists(expr)) {
    stop("The discordance score matrix or gene expression matrix file does not exist.")
  }
  if (!file.exists(metadata)) {
    stop("The metadata file does not exist.")
  }
  
  priority_rts_path <- system.file("extdata", priority_rts, package = "Triage")
  
  script_command <- sprintf(
    "sys.argv = ['%s', '--expr', '%s', '--metadata', '%s', '--outdir', '%s', '--output_prefix', '%s', '--cell_column', '%s', '--umap_column', '%s', '--priority_rts', '%s', '--min_cells_per_peak', '%d']",
    gsub("\\\\", "/", normalizePath(path, winslash="/", mustWork=FALSE)),
    expr,
    metadata,
    outdir,
    output_prefix,
    cell_column,
    umap_column,
    gsub("\\\\", "/", normalizePath(priority_rts_path, winslash="/", mustWork=FALSE)),
    min_cells_per_peak)
  
  # tryCatch for error handling
  tryCatch({
    reticulate::py_run_string("import sys")
    reticulate::py_run_string(script_command)
    reticulate::py_run_file(path)
  }, error = function(e) {
    stop("Error occurred while executing the Python script: ", e$message)
  })
}
