#' @title TRIAGEgene
#'
#' @description 
#' TRIAGEgene computes a discordance score matrix based on gene-repressive tendencies derived from either the EpiMap (default) or the NIH Epigenome Roadmap H3K27me3 data, combined with the provided normalised gene expression data. 
#' Originally named TRIAGE, this function has been renamed to TRIAGEgene to emphasize its focus on gene-level TRIAGE analysis. 
#' For more in-depth details, refer to: Shim et al., Cell Systems 2020, "Conserved Epigenetic Regulatory Logic Infers Genes Governing Cell Identity".

# Summary of changes/improvements for the TRIAGEgene function:
# 1. Using 'match' instead of a combination of 'which' and '%in%' allows for a faster extraction of data.
# 2. Enhanced performance by leveraging Matrix and vector operations in R, which are typically faster than functions like 'sapply' (as used in the original code).
# 3. Default values are provided for `species`, `log`, and `data_source` parameters.
# 4. Validity checks are implemented for all three parameters to ensure they have correct values.
# 5. When `species` is set to "Human", the appropriate RTS file is selected based on the `data_source`.
# 6. For species other than "Human", genes that may correspond to multiple RTS values are handled by calculating average values.
# 7. Introduced case insensitivity for the `data_source` parameter, offering users a more forgiving input method.
# 8. Stats for the number of genes (and its percentage) that can be found in the RTS table are now provided, increasing awareness of potential gene name mapping issues (or incorrect species).

#'
#' @param m The input matrix or data.frame of normalised gene expression data. Types can include CPM, FPKM, TPM, or other normalised gene expression data. 
#' @param species A character string indicating the species. Default is "Human". Other options are "C.intestinalis", "Chicken", "Guinea Pig", "Mouse", "Pig", "Zebrafish".
#' @param log Logical value indicating whether the input matrix data (normalized gene expression data) should be log-transformed. 
#' The default value is NULL, which allows TRIAGEgene to determine whether log transformation is necessary based on the data characteristics.
#' If set to TRUE, the function applies a natural logarithm transformation to the input data. If set to FALSE, no logarithm transformation is applied.
#' Based on extensive testing, we have found that the TRIAGEgene function typically performs optimally when gene expression data is transformed using the natural logarithm.
#' @param data_source A character string indicating the data source to use, either "epimap" (default) or "roadmap".
#'
#' @return A discordance score matrix.
#'
#' @examples
#' \dontrun{
#' # Apply TRIAGEgene to human data, letting TRIAGEgene decide whether to perform a log transformation.
#' result <- TRIAGEgene(input)

#' # Apply TRIAGEgene to human data with the 'roadmap' data source instead of the default 'EpiMap', 
#' letting TRIAGEgene decide on log transformation.
#' result <- TRIAGEgene(input, data_source = "roadmap")

#' # Apply TRIAGEgene to human data and force a log transformation.
#' result <- TRIAGEgene(input, log = TRUE)

#' # Apply TRIAGEgene to Mouse data without performing a log transformation.
#' result <- TRIAGEgene(input, species = "Mouse", log = FALSE)
#' }

#'
#' @export
#' @importFrom data.table fread
TRIAGEgene <- function(m, species = "Human", log = NULL, data_source = "epimap"){
  # Check if provided species is valid
  valid_species <- c("Human", "C.intestinalis", "Chicken", "Guinea Pig", "Mouse", "Pig", "Zebrafish")
  if (!species %in% valid_species) {
    stop("Invalid species provided. Choose from:", paste(valid_species, collapse=", "), ".")
  }

  if (is.null(log)) {
    max_value <- max(m, na.rm = TRUE)
    log <- max_value >= 20
    if (log) {
      message("Based on the data, log transformation will be applied for better analysis accuracy (log = TRUE).") 
    } else {
      message("Based on the data, log transformation is not necessary and will not be applied (log = FALSE).")
    }
  }
  # Check if log is a logical value
  if (!is.logical(log)) {
    stop("Invalid 'log' argument. It should either be a logical (TRUE or FALSE) or NULL.")
  }
  
  # Check if data_source is valid
  valid_data_sources <- c("epimap", "roadmap")
  if (!tolower(data_source) %in% valid_data_sources) {
    stop("Invalid data_source provided. Choose from:", paste(valid_data_sources, collapse=", "), ".")
  }
  
  if (species == "Human") {
    if (tolower(data_source) == "epimap") {
      rts_path <- system.file("extdata", "human_rts_epimap.txt", package = "Triage")
    }else{
      rts_path <- system.file("extdata", "human_rts_roadmap.txt", package = "Triage")
    }
    rts <- as.data.frame(fread(rts_path))
    
    # Use match to get the indices of gene_names in rts
    indices <- match(row.names(m), rts$V1)
    
    # Initialize l with zeros
    l <- numeric(nrow(m))
    
    # For matched genes, fill the corresponding RTS values
    matched_indices <- which(!is.na(indices))
    l[matched_indices] <- rts$V2[indices[matched_indices]]
    
    # Calculate the percentage of genes not found in the RTS table
    not_found <- sum(is.na(indices))
    total_genes <- length(l)
    found <- total_genes - not_found
    found_percentage <- round((found / total_genes) * 100, 2)
    not_found_percentage <- round((not_found / total_genes) * 100, 2)
    if (found_percentage < 50) {
      message("The TRIAGEgene analysis has been completed, but the results may contain some issues.")
      warning(paste0(not_found_percentage, "% of the input genes were not found in the RTS table. Please check the species/gene names provided."))
      #warning("More than 50% of the genes were not found in the RTS table. Please check the species/gene names provided.")
    }else{
      message("The TRIAGEgene analysis has been completed.")
    }
    message(paste0("Number of genes (%) found in RTS table: ", found, " (", found_percentage, "%)"))
    #message(paste("Number of genes found in RTS table:", found))
    #message(paste("Percentage of genes found in RTS table:", found_percentage, "%"))
  } else {
    g.col <- paste(species, "gene name")
    rts_path <- system.file("extdata", "rts.txt", package = "Triage")
    rts <- as.data.frame(fread(rts_path, header=TRUE, sep="\t", fill=TRUE))
    
    # One gene might match to multiple human genes, hence having multiple RTS values. 
    # In such scenarios, the average RTS value is assigned to the gene.
    
    # Identify rows in "rts.txt" with unique combinations of rts[, g.col] and rts[,"Gene name"]
    unique_rts_rows <- rts[!duplicated(rts[, c("Gene name", g.col)]), ]
    
    input_genes <- row.names(m)
    l <- numeric(length(input_genes))
    not_found <- 0
    for (gene in input_genes) {
      # Now, using the unique_rts_rows data frame, get the RTS value for each gene
      matches <- which(unique_rts_rows[, g.col] == gene)
      
      if (length(matches) > 1) {
        l[which(input_genes == gene)] <- mean(unique_rts_rows$RTS[matches])
      } else if (length(matches) == 1) {
        l[which(input_genes == gene)] <- unique_rts_rows$RTS[matches]
      } else{
        # if no match, the RTS will remain 0 for that gene
        not_found <- not_found + 1
      }
    }
    
    # Calculate the percentage of genes not found in the RTS table
    total_genes <- length(l)
    found <- total_genes - not_found
    found_percentage <- round((found / total_genes) * 100, 2)
    not_found_percentage <- round((not_found / total_genes) * 100, 2)
    if (found_percentage < 50) {
      message("The TRIAGEgene analysis has been completed, but the results may contain some issues.")
      warning(paste0(not_found_percentage, "% of the input genes were not found in the RTS table. Please check the species/gene names provided."))
    } else{
      message("The TRIAGEgene analysis has been completed.")
    }
    message(paste0("Number of genes found in RTS table: ", found, " (", found_percentage, "%)"))
    #message(paste("Number of genes found in RTS table:", found))
    #message(paste("Percentage of genes found in RTS table:", found_percentage, "%"))
  }

  #if (is.data.frame(m)) {
  #  m <- as.matrix(m)
  #}  
  #if(any(is.nan(m))  || any(m < 0)){
  #  warning("Please double check your input: NaN values or negative numbers exist in the input. Replacing NaNs and negative numbers with 0.")
  #  m[is.nan(m) | m < 0] <- 0
  #}
  
  # to check whether the input matrix data (normalised gene expression data) needs to be log transformed or not. Default is "NULL" (i.e. determine it by TRIAGEgene).
  if(log){
    out <- log(m+1)*l
  } else {
    out <- m*l
  }
  return(out)
}

