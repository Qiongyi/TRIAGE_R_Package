#' plot Jaccard Heatmap
#'
#' Generates a Jaccard index heatmap based on the output from TRIAGEgene.
#'
#' @param ds The output from the TRIAGEgene function.
#' @param output_file The desired name of the output heatmap PDF file.
#' @param top_no The number of top TRIAGE ranked genes to consider for the Jaccard index calculation.
#' @return Generates a Jaccard index heatmap PDF file.
#' @export
#' @examples
#' \dontrun{
#' ds <- TRIAGEgene(input_matrix)
#' plotJaccard(ds, "Jaccard_heatmap.pdf")
#' }
#' 
#' @importFrom grDevices graphics.off pdf dev.off colorRampPalette
plotJaccard <- function(ds, output_file, top_no = 100){
  graphics.off()
  #library(pheatmap)
  jaccard_table <- function(input_table, top_no = 100){
    results <- data.frame(matrix(ncol = ncol(input_table), nrow = ncol(input_table)))
    rownames(results) <- colnames(input_table)
    colnames(results) <- colnames(input_table)
    for (col1 in colnames(input_table)) {
      r1 <- rownames(input_table)[order(input_table[, col1], decreasing = TRUE)[1:top_no]]
      for (col2 in colnames(input_table)) {
        r2 <- rownames(input_table)[order(input_table[, col2], decreasing = TRUE)[1:top_no]]
        value <- length(intersect(r1, r2)) / length(unique(c(r1, r2)))  # Jaccard index
        results[col1, col2] <- value
      }
    }
    return(results)
  }
  
  temp <- ds
  if(!is.numeric(ds[, 1])){
    # the first column lists gene names and not needed for the Jaccard index heatmap
    temp <- temp[, -1]
  }
  corr_table <- jaccard_table(temp, top_no)
  #min_val <- min(corr_table, na.rm = TRUE)
  #max_val <- max(corr_table, na.rm = TRUE)
  #breaks <- seq(min_val, max_val, length.out = 10)
  #print(paste("Minimum value in corr_table:", min_val))
  #print(paste("Maximum value in corr_table:", max_val))
  
  pdf(output_file, width = 10, height = 10)
  pheatmap::pheatmap(corr_table)
  #pheatmap::pheatmap(corr_table, breaks = breaks)
  dev.off()
}
