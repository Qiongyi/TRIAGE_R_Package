#' Plot GO Enrichment Heatmap
#'
#' Generates GO enrichment heatmaps based on the output from TRIAGEparser. 
#' This function creates heatmaps to visualize the GO enrichment analysis results for specific groups or IDs, 
#' as identified in the Discordance Score (DS) table used as input for TRIAGEparser.
#'
#' @param indir The path to the output directory from TRIAGEparser.
#' @param outdir The output directory where the generated heatmap PDF files will be saved.
#' @param id An optional parameter to specify a particular group or ID for which 
#'                     the heatmap is to be generated. This id must match one of the column 
#'                     names in the Discordance Score (DS) table (provided as (i.e. the input file for TRIAGEparser).
#'                     If NULL, heatmaps for all groups/IDs will be generated. Default: NULL.
#' @param color_palette An optional color palette for the heatmap. If NULL, a default palette will be used. 
#'                     Default: colorRampPalette(c("lightgrey", "purple", "red"))(n = 100).
#' @param top_terms The number of top GO terms to include in the heatmap. Default: 10.
#' @return Generates GO enrichment heatmap PDF files.
#' @export
#' @examples
#' \dontrun{
#' # The DS table snippet:
#' # GENE    E071    E016    E004
#' # RNF14   0.000215 0.000155 0.000159
#' # UBE2Q1  0.000256 0.00027  0.00029
#' # RNF17   0.0      0.0      0.0
#' # RNF10   0.000326 0.000338 0.000346
#'
#' # Example 1: Generate heatmaps for all groups/IDs ("E071", "E016", "E004")
#' plotGO(indir = "path/to/TRIAGEparser_output", 
#'        outdir = "path/to/heatmap_output")
#'
#' # Example 2: Generate heatmap only for specific group “E016”
#' plotGO(indir = "path/to/TRIAGEparser_output", 
#'        outdir = "path/to/heatmap_output", 
#'        id = "E016")
#'
#' # Example 3: Generate heatmap for “E016” with custom color gradient (e.g. white to red)
#' plotGO(indir = "path/to/TRIAGEparser_output", 
#'        outdir = "path/to/heatmap_output",
#'        id = "E016", 
#'        color_palette = colorRampPalette(c("white", "red"))(n = 100))
#' }

#' @importFrom grDevices graphics.off pdf dev.off colorRampPalette
plotGO <- function(indir, outdir, id = NULL, color_palette = NULL, top_terms = 10) {
  graphics.off()
  # Default color palette
  if (is.null(color_palette)) {
    color_palette <- colorRampPalette(c("lightgrey", "purple", "red"))(n = 100)
  }
  
  idx_for_top_values <- function(matrix, no_terms, col_order) {
    idx <- vector()
    for (col in col_order) {
      temp <- order(matrix[, col], decreasing = TRUE)[1:no_terms]
      idx <- c(idx, temp)
    }
    idx <- unique(idx)
    return(idx)
  }
  
  check_threshold <- function(column, threshold) {
    max_value <- max(column)
    return(max_value < threshold)
  }
  
  # Generate heatmap for a particular group or ID or all groups or IDs
  files <- if (!is.null(id)) {
    specified_file <- paste0(indir, "/go/", id, "_go.txt")
    alt_specified_file <- paste0(indir, "/", id, "_go.txt")
    
    # Check if the specified file exists in either location
    if (file.exists(specified_file)) {
      specified_file
    } else if (file.exists(alt_specified_file)) {
      alt_specified_file
    } else {
      stop("Specified file *_go.txt not found in either 'go' subdirectory or the provided directory.")
    }
  } else {
    go_path <- paste0(indir, "/go")
    alt_path <- indir
    
    # Check and return files from either the 'go' subdirectory or the provided directory
    if (dir.exists(go_path)) {
      list.files(path = go_path, pattern = "_go\\.txt$", full.names = TRUE)
    } else if (dir.exists(alt_path)) {
      list.files(path = alt_path, pattern = "_go\\.txt$", full.names = TRUE)
    } else {
      stop("No 'go' subdirectory or *_go.txt files found in the provided directory.")
    }
  }
  
  for (file_path in files) {
    group <- basename(file_path)
    group <- gsub("_go\\.txt$", "", group)
    
    # Read and process file
    table_ <- read.table(file_path, stringsAsFactors = FALSE)
    table_[table_ == 1] <- 0.999
    table_ <- -log10(table_)
    rownames(table_) <- gsub('_', ' ', rownames(table_))
    
    # Determine gene clusters to plot
    clusters_to_plot <- apply(table_, 2, check_threshold, threshold = -log10(0.01))
    if (all(clusters_to_plot)) { next }
    
    table_to_plot <- table_[, !clusters_to_plot, drop = FALSE]
    idx <- idx_for_top_values(matrix = table_to_plot, no_terms = top_terms, col_order = colnames(table_to_plot))
    
    # Generate heatmap PDF
    if (length(idx) > 0) {
      pdf_filename <- paste0(outdir, "/", group, '_go_heatmap.pdf')
      pdf(pdf_filename, width = 7, height = 6)
      pheatmap::pheatmap(table_to_plot[idx,, drop = FALSE], cluster_cols = FALSE, cluster_rows = FALSE, color = color_palette, border_color = NA)
      dev.off()
    }
  }
}
