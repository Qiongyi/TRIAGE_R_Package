#' Calculate Average Gene Expression or Discordance Score (DS) by Peak
#'
#' This function calculates the average expression or DS of each gene grouped by peak values.
#' It iterates through unique peak values, selects the cells corresponding to each peak,
#' and computes the mean expression for each gene. It supports both direct data frame input
#' and reading from CSV or TXT files.
#'
#' @param expr Either a data frame with genes as rows and cells as columns, or a path to a CSV/TXT file containing the expression data.
#' @param peak Either a data frame containing at least two columns for cell IDs and peaks, or a path to a CSV/TXT file containing the metadata including cell IDs and peaks.
#' @param cell_id_col Name of the column in metadata representing cell IDs (default: "Barcode").
#' @param peak_col Name of the column in metadata representing peak values (default: "Peak").
#' @return A data frame with average gene expression or DS values grouped by peak.
#' @export
#' @examples
#' \dontrun{
#'   result <- byPeak(expr = "path/to/expression.csv", metadata = "path/to/metadata.csv")
#'   head(result)
#' }
#' 
#' @importFrom utils read.csv read.delim read.table
byPeak <- function(expr, peak, cell_id_col = "Barcode", peak_col = "Peak") {

  read_data <- function(data, is_expr = FALSE) {
    if (is.character(data)) {
      if (grepl("\\.csv$", data)) {
        df <- read.csv(data, stringsAsFactors = FALSE)
      } else if (grepl("\\.(txt|tsv)$", data)) {
        df <- read.delim(data, stringsAsFactors = FALSE)
      } else {
        stop("File format not supported. Please provide a CSV or TXT file.")
      }
    } else {
      df <- data
    }
    
    #
    if (is_expr) {
      # set the rownames
      rownames(df) <- df[,1]
      df <- df[,-1]
    }
    
    return(df)
  }
  
  
  expr <- read_data(expr, is_expr = TRUE)
  peak <- read_data(peak)
  
  avg_expr_by_peak <- data.frame()
  unique_peaks <- sort(unique(peak[[peak_col]][!is.na(peak[[peak_col]])]))
  
  for (n in unique_peaks) {
    cells_in_peak <- peak[[cell_id_col]][peak[[peak_col]] == n]
    cells_in_peak <- cells_in_peak[!is.na(cells_in_peak)]
    
    if (length(cells_in_peak) > 0) {
      expr_subset <- expr[, cells_in_peak, drop = FALSE]
      avg_expr <- rowMeans(expr_subset, na.rm = TRUE)
      
      if (ncol(avg_expr_by_peak) == 0) {
        avg_expr_by_peak <- data.frame(avg_expr)
        #names(avg_expr_by_peak) <- paste("Peak", n, sep="")
      } else {
        avg_expr_by_peak <- cbind(avg_expr_by_peak, avg_expr)
        #names(avg_expr_by_peak)[ncol(avg_expr_by_peak)] <- paste("Peak", n, sep="")
      }
      
      # Set column name based on peak_col value
      if (peak_col == "Peak") {
        col_name <- paste("Peak", n, sep="")
      } else {
        col_name <- n
      }
      names(avg_expr_by_peak)[ncol(avg_expr_by_peak)] <- col_name
    }
  }
  
  return(avg_expr_by_peak)
}
