##############################################################################################
### TRIAGEparser                                                                           ###
###   Orginally developed by Woo Jun (Chris) Shim                                          ###
###   contact: w.shim@uq.edu.au                                                            ###
###                                                                                        ###
###                                                                                        ###
###   Improved & updated by Qiongyi Zhao in Nov 2023                                       ###
###   contact: q.zhao@uq.edu.au                                                            ###
###     1) Support .csv file as the input file                                             ###
###     2) Capture & use the lastest version of string-db                                  ###
###     3) Add the tolerance and max_iterations parameters to give users control over      ###
###        the convergence criteria for the Gaussian Mixture Model fitting procedure.      ###
###     4) Replace optparse with argparse module to ensure forward compatibility.          ###
###     5) Use time.sleep() to wait one second between each call, so that the string-db    ###
###        server won't get overloaded.                                                    ###
###     6) Create a requests session with retry logic for string-db to handle the          ###
###        potential connection error.                                                     ###
###     7) Fix some minor bugs.                                                            ###
##############################################################################################

### Modules
import numpy as np
import pandas as pd
import os, sys, scipy.stats, collections, requests
import requests, json
import argparse
from sklearn.mixture import GaussianMixture
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import time

### Functions
def read_file_items(filename, col=0, numeric=False):
	results = []

	if filename.endswith('.csv'):
		import csv
		with open(filename, 'r') as csvfile:
			reader = csv.reader(csvfile)
			for row in reader:
				if row and not row[0].startswith('#'):
					value = row[col]
					if numeric:
						value = float(value)
					results.append(value)
	else:				
		with open(filename, 'r') as file:
			for line in file:
				if not line.startswith('#'):
					i = line.strip().split()
					if numeric==False:
						results.append(i[col])
					else:
						results.append(float(i[col]))
	return results

def read_and_process_file(input_path, sep='\t', gene_col='GENE'):
    if input_path.endswith('.csv'):
        sep = ','
    disc = pd.read_csv(input_path, sep=sep)
    if gene_col in disc.columns:
        disc.set_index(gene_col, inplace=True)
    else:
        disc.rename(columns={disc.columns[0]: gene_col}, inplace=True)
        disc.set_index(gene_col, inplace=True)
    return disc

def intersection(data1, data2):
	# takes a pair of lists and returns a list of shared items
	# data1 or data2 = a list of elements
	a = collections.Counter(data1)
	b = collections.Counter(data2)
	return list((a & b).elements())

def most_frequent_element(input_list): 
	# find an element in the list with the highest count
	sorted_unique_elements = sorted(set(input_list), key=lambda x: input_list.index(x))
	most_frequent = sorted_unique_elements[0]
	highest_count = input_list.count(most_frequent)
	for element in sorted_unique_elements[1:]: 
		current_count = input_list.count(element)
		if current_count > highest_count: 
			highest_count = current_count 
			most_frequent = element
	return most_frequent


def write_table(input_data, output_file, numeric=False):
	# exports a table text file 
	# takes a dictionary of dictionaries (e.g. input_data[row1][col1]=xx, input_data[row1][col2]=xx, ..)
	if input_data:    
		with open(output_file, 'w') as output_:
			rownames = sorted(input_data.keys())
			colnames = sorted({str(col) for row in input_data for col in input_data[row].keys()}, key=lambda x: int(x) if numeric else x)

			first_line = '\t' + '\t'.join(colnames)
			output_.write(first_line + '\n')

			for row in rownames:
				line = str(row) + '\t' + '\t'.join(str(input_data[row].get(col, '')) for col in colnames)
				output_.write(line+'\n')

def find_gmm_cluster(input_list):
	temp = pd.read_csv(input_list, index_col='GENE')
	group = {}	
	for i in temp.columns:
		group[i] = []
	for j in range(temp.shape[0]):	# find the cluster for all genes
		id_ = temp.columns[np.argmax(temp.iloc[j])]
		group[id_].append(temp.index[j])
	return group

def create_sig_go_gmm_table(groups, ppi_threshold=0.01, enrichment_threshold=0.01, species=9606):
	# test ppi enrichment and if significant create a summary data (description, fdr, cluster)
	output_ = {}
	clusters = []
	for i in range(1, len(groups)+1):
		test = api_string(session=session, genes=groups['cluster'+str(i)], method='ppi_enrichment', output_format="tsv", species=species)
		#print (float(test[-1][-1]))
		if not test[0][0] =='Error':
			if float(test[-1][-1]) < ppi_threshold:
				clusters.append(i)	
				if args.verbose==1:
					print ('cluster'+str(i),', PPI enrichment p-value =',float(test[-1][-1]))
	#print (ppi_threshold, clusters)
	for i in clusters:
		results = api_string(session=session, genes=groups['cluster'+str(i)], method='enrichment', species=species, enrichment_threshold=enrichment_threshold)	
		output__ = [[results[i][-1], float(results[i][-2])] for i in range(len(results))]		
		for j in output__:
			name = j[0].replace(' ','_')		
			if name not in output_:
				output_[name] = {}
				for m in clusters:
					output_[name]['cluster'+str(m)] = 1
			output_[name]['cluster'+str(i)] = j[1]
	return output_

def get_latest_string_version():
    version_api_url = "https://string-db.org/api/json/version"
    default_version_url = "https://version-11-5.string-db.org"
    try:
        response = requests.get(version_api_url)
        response.raise_for_status()  # This will raise an HTTPError if the HTTP request returned an unsuccessful status code
        version_info = response.json()
        return version_info[0]['stable_address']
    except requests.HTTPError:  # Catch HTTP errors
        print(f"Using default STRING DB version URL: {default_version_url}")
        return default_version_url
    except requests.RequestException as e:  # Catch other requests-related exceptions
        print(f"Request failed: {e}")
        return default_version_url

def print_version_info(string_api_url):
    global printed_version_info
    if not printed_version_info:
        print(f"Using STRING DB URL: {string_api_url}")
        printed_version_info = True


def api_string(session, genes, method='ppi_enrichment', output_format="json", species=9606, enrichment_threshold=0.01):
	# returns enrichment data from STRING using API
	# GO enrichment, method='enrichment'
	# PPI enrichment, method='ppi_enrichment'
	string_api_url = get_latest_string_version()
	#string_api_url = "https://version-11-5.string-db.org/api"
	#print(f"Using STRING DB URL: {string_api_url}")  # Print the URL being used
	print_version_info(string_api_url)
	request_url = "/".join([string_api_url, "api", output_format, method])
	params = {"identifiers" : "%0d".join(genes), "species" : species, "caller_identity" : "comodulation"}
	
	try:
		# Use session with retry logic to send request with a timeout set
		response = session.post(request_url, data=params, timeout=10)
		#response = requests.post(request_url, data=params)
		# wait one second between each call, so that the string-db server won't get overloaded.
		time.sleep(1)
		results = []
		if method=='ppi_enrichment':	# tsv 
			for line in response.text.strip().split("\n"):
				results.append(line.split("\t"))
		else:
			data = json.loads(response.text)	# json
			for row in data:
				term = row["term"]
				preferred_names = ",".join(row["preferredNames"])
				fdr = float(row["fdr"])
				description = row["description"]
				category = row["category"]
				if category == "Process" and fdr < enrichment_threshold:
					results.append([term, preferred_names, str(fdr), description])    
		return results
	except requests.exceptions.ConnectionError as e:
		print(f"Failed to connect to STRING database API: {e}")
	except requests.exceptions.Timeout as e:
		print(f"Request to STRING database API timed out: {e}")
	

def write_file(data, filename):	
	temp = open(filename, 'w')
	line = '#gene'
	for item in data.columns:
		line += '\t'+str(item)
	temp.write(line+'\n')
	genes = data.index
	for i in range(data.shape[0]):
		line = genes[i]
		for j in range(data.shape[1]):
			line += '\t'+str(data.iloc[i,j])
		temp.write(line+'\n')
	temp.close

def calculate_variance(input):
	return [np.var(input.iloc[:,i]) for i in range(input.shape[1])]


if __name__ == '__main__':
	### Command line options   
	parser = argparse.ArgumentParser(description='TRIAGEparser is a machine learning-based method that evaluates gene expression rank lists to identify gene groups governing cell identity and function.')

	parser.add_argument('-i', '--input', required=True, help='The input file should be a .csv (comma-separated) or a text file with tab or space-delimited format.')
	parser.add_argument('-a', '--input_type', help='Input type (option: table or list). Default is list.', default='list', choices=['table', 'list'])
	parser.add_argument('-r', '--H3K27me3_pc', help='Path to pre-calculated H3K27me3 principal components. Default is "./data/pca_roadmap".', default='./data/pca_roadmap')
	parser.add_argument('-p', '--number_of_pca', help='Number of PCs to use. Default is 10.', default=10, type=int)
	parser.add_argument('-g', '--number_of_gene', help='Number of top genes to use. Default is 100.', default=100, type=int)
	parser.add_argument('-t', '--no_iter', help='Number of iterations for determining the best number of clusters using the Bayesian Information Criterion (BIC). Default is 100.', default=100, type=int)
	parser.add_argument('-l', '--EM_tol', help='The convergence threshold for the GaussianMixture function. Expectation–maximization (EM) iterations will stop when the lower bound average gain is below this threshold. Default is 1e-3.', default=1e-3, type=float)
	parser.add_argument('-m', '--EM_max_iter', help='The number of EM iterations to perform for the GaussianMixture function. Default is 100.', default=100, type=int)
	parser.add_argument('-o', '--outdir', help='Output directory. Default is "TRIAGEparser_output".', default='TRIAGEparser_output')
	parser.add_argument('-e', '--go_analysis', help='Whether to perform GO enrichment analysis (1: Yes, 0: No). Default is 1.', default=1, type=int)
	parser.add_argument('-v', '--verbose', help='Level of verbose (option: 1 or 0). Default is 1.', default=1, type=int)
	parser.add_argument('-w', '--max_cluster', help='Max number of clusters. Default is 10.', default=10, type=int)
	parser.add_argument('-j', '--gene_order', help='Specifies the direction to sort genes (option: ascending or descending). Default is descending.', default='descending', choices=['ascending', 'descending'])
	parser.add_argument('-q', '--go_threshold', help='GO term enrichment threshold (FDR). Default is 0.01.', default=0.01, type=float)

	args = parser.parse_args()

	if args.input == None:
		sys.exit('Exiting: input (TRIAGE output table or a list of genes) is required (-i)')
	else:
		if not os.path.exists(args.outdir):
			os.mkdir(args.outdir)
		if not os.path.exists(args.outdir+'/gene_clusters'):
			os.mkdir(args.outdir+'/gene_clusters')

		### 0. Print the version of string-db & create a retry logic
		printed_version_info = False
		# Create a requests session with retry logic
		session = requests.Session()
		retries = Retry(total=10,  # Total number of retries
				backoff_factor=0.1,  # Interval between retries
				status_forcelist=[500, 502, 503, 504])  # Status codes to trigger a retry
		# 500 Internal Server Error；
		# 502 Bad Gateway
		# 503 Service Unavailable
		# 504 Gateway Timeout
		session.mount('https://', HTTPAdapter(max_retries=retries))

		### 1. Load data
		#print("Attempting to read file at:", args.H3K27me3_pc+'.csv')
		pca = pd.read_csv(args.H3K27me3_pc+'.csv', index_col='GENE')
		rows = pca.index
		cols = pca.head()

		if args.input_type=='table':
			disc = read_and_process_file(args.input)
			labels = disc.columns
			#labels = disc.head()
			#print(labels)
			#sys.exit()
		else:
			labels = ['output']
		if args.input_type=='list':
			genes = read_file_items(args.input)
			args.number_of_gene = len(genes)
		if args.verbose==1:
			print ("Using", args.number_of_pca, 'top PCs from top', args.number_of_gene, 'genes with',args.no_iter,'iterations for model selection')

		### 2. Find gene clusters
		if args.verbose==1:	
			print ('Finding gene clusters ...')
		for label in labels:
			if args.verbose==1:
				print (label)
			if args.input_type=='table':
				if args.gene_order=='descending':	
					genes = disc.sort_values(by=[label], ascending=False).index[:args.number_of_gene]
				else:
					genes = disc.sort_values(by=[label], ascending=True).index[:args.number_of_gene]
			# else:
			# 	genes = read_file_items(args.input)
			genes = intersection(genes, rows)
			aa = pca.loc[genes]

			# find PCs with most variance among the gene set
			cc = calculate_variance(aa)
			idx = list(np.argsort(cc))
			idx.reverse()
			aa = aa.iloc[:,idx[:args.number_of_pca]]

			# Set a random state for reproducibility
			random_state = 42

			# find an optimal number of clusters using Bayesian information criterion 
			bic_ = []
			for no in range(args.no_iter):
				bic_result = []
				for n in range(2, args.max_cluster):
					gmm = GaussianMixture(n_components=n, tol=args.EM_tol, max_iter=args.EM_max_iter, random_state=random_state).fit(aa)
					bic_result.append(gmm.bic(aa))
				bic_.append(bic_result.index(np.min(bic_result)) + 1)  
			n = most_frequent_element(input_list=bic_)
			if args.verbose==1:
				print ('Number of cluster =', n)
			gmm = GaussianMixture(n_components=n, tol=args.EM_tol, max_iter=args.EM_max_iter, random_state=random_state).fit(aa)
			bb = pd.DataFrame(gmm.predict_proba(aa))
			bb.index = genes
			results = pd.DataFrame(columns=['cluster'+str(i+1) for i in range(n)], index=genes)

			for i in range(len(genes)):
				results.loc[genes[i]] = list(bb.iloc[i])
			results.to_csv(args.outdir+'/gene_clusters/'+label+'_gene_clusters.csv', index_label='GENE')

		### 3. GO ENRICHMENT 
		if args.go_analysis==1:
			if args.verbose==1:
				print ('Performing GO enrichment analysis ... ')
			if not os.path.exists(args.outdir+'/go'):
				os.mkdir(args.outdir+'/go')
			files = os.listdir(args.outdir+'/gene_clusters/')
			files.sort()		
			for i in files:
				a = i.split('_gene_clusters')
				name = a[0]
				if args.verbose==1:
					print (a[0])
				groups = find_gmm_cluster(input_list=args.outdir+'/gene_clusters/'+name+'_gene_clusters.csv')
				#print (groups)
				results = create_sig_go_gmm_table(groups=groups, ppi_threshold=0.01, enrichment_threshold=args.go_threshold)
				#print (results)
				write_table(results, args.outdir+'/go/'+name+'_go.txt')
