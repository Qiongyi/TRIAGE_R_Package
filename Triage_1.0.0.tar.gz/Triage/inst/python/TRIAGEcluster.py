##############################################################################################
### TRIAGEcluster                                                                          ###
###   Orginally developed by Yuliangzi (Vera) Sun                                          ###
###   contact: yuliangzi.sun@uq.edu.au                                                     ###
###                                                                                        ###
###   Code rewritten by Qiongyi Zhao in Nov-Dec 2023                                       ###
###   contact: q.zhao@uq.edu.au                                                            ###
###                                                                                        ###
##############################################################################################

### Modules
import os
import argparse
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns 
import numpy as np
import matplotlib
from scipy import stats
from sklearn.cluster import DBSCAN
from scipy.io import mmread
import sys
from pathlib import Path
import warnings
warnings.filterwarnings("ignore", category=UserWarning, message="The figure layout has changed to tight")


np.random.seed(0)

def gene_assign(exp_df, meta_df, rts_df):
    comm_genes = exp_df.index.intersection(rts_df["Gene"])
    
    exp_df_sub = exp_df.loc[comm_genes,:]
    rts_df_sub = rts_df.loc[rts_df.index[rts_df["Gene"].isin(comm_genes)], :]
    
    exp_df_sub_ = exp_df_sub.copy()
    for index, row in rts_df_sub.iterrows():
        gene = row["Gene"]
        p_cells = exp_df_sub_.columns[exp_df_sub_.loc[gene, :] > 0]
        
        meta_df.loc[p_cells, "v1gene"] = gene
        meta_df.loc[p_cells, "RTS"] = row["RTS"]
        
        exp_df_sub_.drop(p_cells, axis=1, inplace=True)
        #print(len(exp_df_sub_.columns)) #check how many cells left after each loop
    
    return meta_df

def getBlacklist(blacklistthese):
	out = []
	if isinstance(blacklistthese, list):
		for peak in blacklistthese:
			levels = peak.split('_')
			out = out + ['_'.join(levels[0:n]) for n in range(1, len(levels))]
	else: # if there's only one peak in blacklistthese
		levels = blacklistthese.split('_')
		out = out + ['_'.join(levels[0:n]) for n in range(1,len(levels))]
	return list(set(out))

# Iterate over all cluster strings, which represent the specific cluster each cell belongs to at every contour clustering level, 
# and select only those clusters that are identified as peaks (i.e., regions of cells that do not encompass smaller sub-regions within them).
def getPeaks(clusterstrings):
	usc = list(set(clusterstrings)) # get unique clusterstrings
	peaks = [] # what we want to keep
	blacklist = [] # the clusters that have smaller clusters inside them
	# loop through clusterstrings and get peaks
	while len(usc) > 0 and '_' in usc[0]: 
		newpeaks = [u for u in usc if u.endswith('nan') == False] # we only want to keep those that don't end with none/NA
		# print(newpeaks)
		peaks = list(set(peaks + newpeaks))
		# blacklist all the clusters that the peaks on this level are in 
		newblacklist = getBlacklist(peaks)
		# print('Newly blacklisted', len(newblacklist), 'clusters')
		# print(set(newblacklist))
		blacklist = list(set(blacklist + newblacklist))
		# remove any peaks that are in the updated blacklist
		usc = [peak for peak in ['_'.join(u.split('_')[:-1]) for u in usc] if peak not in blacklist]
		if len(usc) == 1 and usc[0] == 'nan':
			usc = []
		# print('Remaning clusters: ', len(usc))
	peaks = peaks + [u for u in usc if u != 'nan']
	# add nan_ * (total removed levels) to end of each peak so that their total length matches the original cluster string labels
	peaknames = ['_'.join(peak.split('_') + ['nan'] * (len(clusterstrings[0].split('_')) - len(peak.split('_')))) for peak in peaks]
	return(peaknames)

# This function executes the contour clustering process. Prior to running it, the bandwidth must be selected. Typically, this is done by creating several KDE (Kernel Density Estimation) plots with different bandwidth (bw) values to determine the most suitable one.
# df is a pandas DataFrame containing cell barcodes, UMAP coordinate columns, additional metadata, and the RTS values for the TRIAGE gene selected for each cell.
def runcclust(bandwidth, df, cellname, dp, min_cells): 
	# print('calculating density landscape...')
	dim1, dim2 = dp+str(1), dp+str(2)
	kde = stats.gaussian_kde(df.loc[:, [dim1, dim2]].T, weights=df["RTS"])
	kde.set_bandwidth(kde.factor * bandwidth)
	df["density"] = kde(df.loc[:, [dim1, dim2]].T)
	# cut density into 10 contours
	dens_sorted = np.sort(df['density'])
	p = 1. * np.arange(len(df[['density']])) / (len(df[['density']]) - 1)
	thresholds = [dens_sorted[np.where(p == min(p, key=lambda list_value:abs(list_value - x)))] for x in np.arange(0, 1, 0.1)]
	# print('finding clusters on each contour level...')
	df_new = df
	for threshold in thresholds:
		ctypes = df[df['density']>threshold[0]].copy()
		dbscans = DBSCAN(0.2).fit(ctypes.loc[:,[dim1, dim2]])
		# print(np.asarray(np.unique(dbscans.labels_, return_counts=True)).T)
		#sns.relplot(data=ctypes, x=dim1, y=dim2, hue=dbscans.labels_.astype(str), s=1, edgecolor=None, legend='full', facet_kws={'legend_out':True}); plt.suptitle(threshold[0]); plt.show()
		ctypes['cont_'+str(threshold[0])] = dbscans.labels_
		df_new = pd.merge(df_new, ctypes[[cellname, 'cont_'+str(threshold[0])]], how='left', on=cellname)
	# print('getting peaks..')
	cccolidx = [col for col in df_new.columns if col.startswith('cont_')] 
	cccols = df_new[cccolidx[1:]] 
	strcc = cccols.apply(lambda row: '_'.join(row.values.astype('str')), axis = 1)
	peaks = getPeaks(strcc)
	df_new['peaks'] = [s if s in peaks else np.nan for s in strcc]
	
	# ensure each peak has >= minimum number of cells to avoid random (or too many) peaks due to some outlier cells - Qiongyi
	peak_counts = df_new['peaks'].value_counts()  # number of cells in each peak
	valid_peaks = peak_counts[peak_counts >= min_cells].index.tolist()
	df_new['clust'] = [clust if peak in valid_peaks and clust != -1 else np.nan for peak, clust in zip(df_new['peaks'], pd.factorize(df_new['peaks'])[0])]

	#df_new['clust'] = [clust if clust != -1 else np.nan for clust in pd.factorize(df_new['peaks'])[0]]
	firstcellsidx = [list(df_new['clust']).index(clust) for clust in df_new['clust'].unique() if pd.notnull(clust)]
	firstcells = [df_new['clust'][i] if i in firstcellsidx else np.nan for i in range(0, len(df_new))]
	df_new['firstcells_ori'] = firstcells

	# return metadata table
	return(df_new)


def peakplot(df, dp, path):
    dim1, dim2 = dp+str(1), dp+str(2)
    # Get unique clusters and exclude NaN
    valid_clusters = df['clust'].dropna().unique()
    # Sort the clusters to maintain a certain order
    sorted_clusters = np.sort(valid_clusters)
    # Get a continuous range of numbers for the new peak IDs
    new_peak_ids = range(len(sorted_clusters))
    # Create a mapping from old cluster IDs to new continuous peak IDs
    cluster_to_peak = dict(zip(sorted_clusters, new_peak_ids))

    # Apply the mapping to the 'clust' column to get a new 'Peak' column with continuous IDs
    df['Peak'] = df['clust'].map(cluster_to_peak)

    # Apply the same mapping to the 'firstcells' column
    df['firstcells'] = df['firstcells_ori'].map(cluster_to_peak)

    num_peaks = len(new_peak_ids)
    colours = ['#e5e5e5'] + sns.color_palette('husl', num_peaks).as_hex()

    df['Peak'] = pd.Categorical(df['Peak'].astype(str), 
                                categories=['nan'] + df['Peak'].dropna().astype(str).unique().tolist(),
                                ordered=True)

    #colours = ['#e5e5e5'] + sns.color_palette('husl', (len(set(df['peaks'])))-1).as_hex()
    #df['peak'] = pd.Categorical(df['clust'].astype(str), 
    #                            categories=['nan'] + df['clust'].dropna().astype(str).unique().tolist(),
    #                            ordered=True)
    

    g = sns.relplot(data=df, x=dim1, y=dim2, hue=df['Peak'], s=1, edgecolor=None, 
                    palette=colours, legend='full', facet_kws={'legend_out':True}, rasterized=True)
    # To set the size of the legend markers
    #for legobj in g.legend.legendHandles:
    for legobj in g.legend.legend_handles:
    	if isinstance(legobj, matplotlib.lines.Line2D):
            legobj.set_markersize(7)  # Adjust marker size for Line2D objects
    	elif isinstance(legobj, matplotlib.collections.PathCollection):
            legobj.set_sizes([7])  # Adjust size for scatter plot markers
    #plt.legend(markerscale=8)
    # determine the legend size based on the number of peaks
    #num_peaks = len(df['peak'].cat.categories)
    if num_peaks > 70:
        fontsize = '5'
    elif num_peaks <= 70 and num_peaks > 50:
        fontsize = '6'           
    elif num_peaks <= 50 and num_peaks > 35:
        fontsize = '7'    
    elif num_peaks <= 35 and num_peaks > 20:
        fontsize = '8'  
    elif num_peaks <= 20:
        fontsize = '9'

    for t in g.legend.get_texts():
        t.set_fontsize(fontsize)

    for i in range(0, df.shape[0]):
        if df['firstcells'][i].astype('str') != 'nan':
            plt.text(x=df[dim1][i]+0.2, y=df[dim2][i]+0.2, s=df.firstcells[i].astype('int'), size=5)
    #plt.legend(title='Peaks', bbox_to_anchor=(1.05, 1), loc='upper left', borderaxespad=0, fontsize='7')
    # Adjust the figure size to accommodate the legend
    #plt.gcf().set_size_inches(8, 8)
    plt.savefig(path, dpi=300, bbox_inches='tight')
    plt.close()

parser = argparse.ArgumentParser(description='Process TRIAGEcluster.')

### add arguments
parser.add_argument('--expr', type=str, required=True, help='The discordance score matrix or gene expression matrix.')
parser.add_argument('--metadata', type=str, required=True, help='The metadata file.')
parser.add_argument('--outdir', type=str, default='TRIAGEcluster_results', help='The output directory. Default is "TRIAGEcluster_results".')
parser.add_argument('--output_prefix', type=str, default='TRIAGEcluster', help='The output file prefix. Default is "TRIAGEcluster".')

# the cell name column: default is Barcode, user can specify the alternative cell name column
parser.add_argument('--cell_column', default='Barcode', help='Column name for cells. Default is "Barcode".')
# the UMAP column names: default is UMAP_1 and UMAP_2, user can specify the alternative UMAP column names
parser.add_argument('--umap_column', default='UMAP_', help='Prefix for UMAP coordinate columns. Default is "UMAP_".')
# the RTS priority gene list
parser.add_argument('--priority_rts', default='Priority_epimap_rts.csv', help='Path to the priority RTS gene list file. Default is Priority_epimap_rts.csv.')
# minimum number of cells per peak
parser.add_argument('--min_cells_per_peak', type=int, default=5, help='Minimum number of cells per peak. Default is 5.')

args = parser.parse_args()

# Check if the output directory exists, and create it if it does not
if not os.path.exists(args.outdir):
    os.makedirs(args.outdir)

# RTS gene list
rts = pd.read_csv(args.priority_rts, index_col=0)

# expression matrix
if not os.path.exists(args.expr):
    print(f"Error: The expression matrix file '{args.expr}' does not exist.")
    sys.exit(1)
if args.expr.endswith('.csv'):
    expr = pd.read_csv(args.expr, index_col=0)
elif args.expr.endswith('.txt'):
    expr = pd.read_csv(args.expr, index_col=0, delimiter='\t')
else:
    print("Unsupported file format for the expression matrix file. Please provide a .csv (comma delimiter) or .txt (tab delimiter) file.")
    sys.exit(1)

# cell metadata with UMAP coordinates
if not os.path.exists(args.metadata):
    print(f"Error: The metadata file '{args.metadata}' does not exist.")
    sys.exit(1)
if args.metadata.endswith('.csv'):
    meta = pd.read_csv(args.metadata, index_col=0)
elif args.metadata.endswith('.txt'):
    meta = pd.read_csv(args.metadata, index_col=0, delimiter='\t')
else:
    print("Unsupported file format for metadata. Please provide a .csv (comma delimiter) or .txt (tab delimiter) file.")
    sys.exit(1)

cell_col = args.cell_column
umap_col = args.umap_column
umap_x = args.umap_column + "1"
umap_y = args.umap_column + "2"

if cell_col not in meta.columns:
    print(f"Couldn't find column '{cell_col}' in metadata. Please provide the correct column name for cells using --cell_column.")
    sys.exit(1)

if umap_x not in meta.columns or umap_y not in meta.columns:
    print(f"Couldn't find UMAP columns '{umap_x}' and/or '{umap_y}' in metadata. Please provide the correct UMAP prefix using --umap_prefix.")
    sys.exit(1)

# assign RTS score to each cell
meta_new = gene_assign(expr, meta, rts)
meta_new1 = meta_new.dropna()

# generate peaks at different bandwidths, output UMAP with labelled peaks and metadata with only peak cells
#change the path for output
#df is metadata with assigned RTS value for each cell
min_cells_per_peak = args.min_cells_per_peak
bwls=np.arange(0.1, 1.0, 0.1)
for bw in bwls:
    df_new = runcclust(bandwidth = bw, df = meta_new1, cellname = cell_col, dp = umap_col, min_cells=min_cells_per_peak)
    output = f"{args.outdir}/{args.output_prefix}_bw{bw:.2f}_labelledUMAP.pdf"
    peakplot(df_new, umap_col, output)
    df_sub = df_new[df_new['clust'].notna()]
    output = f"{args.outdir}/{args.output_prefix}_bw{bw:.2f}_metadata.csv"
    df_sub.to_csv(output)
